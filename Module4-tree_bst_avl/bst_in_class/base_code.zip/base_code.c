// gcc -o output base_code.c
// ./output "input.txt"

#include <stdio.h>
#include <stdlib.h>
// Node structure
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

// Create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

int main(int argc, char *argv[]) {
    struct Node* root = NULL;
    int choice, data;
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }
    FILE *file = fopen(argv[1], "r"); // Open the input file provided as a command-line argument
    if (file == NULL) {
        printf("Could not open file %s.\n", argv[1]);
        return 1;
    }
    while (fscanf(file, "%d", &choice) != EOF) { // Read the choice from file
        switch (choice) {
            case 1:
                fscanf(file, "%d", &data); // Read data to insert
                // root = insertNode(root, data);
                break;
            case 2:
                fscanf(file, "%d", &data); // Read data to delete
                // root = deleteNode(root, data);
                break;
            case 3:
                fscanf(file, "%d", &data); // Read data to search
                // searchNode(root, data);
                break;
            case 4:
                printf("Height of tree:");
                // printf("%d\n", findHeight(root));
                break;
            case 5:
                printf("In-Order Traversal: ");
                // inOrder(root);
                break;
            default:
                printf("Invalid choice.\n");
                // fclose(file);
                exit(0);
        }
    }
    fclose(file); // Close the file
    return 0;
}
